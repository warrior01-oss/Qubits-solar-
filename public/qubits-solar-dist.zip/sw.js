/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "e605c83263dc1b015c95446723a978d0"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e605c83263dc1b015c95446723a978d0"
  }, {
    "url": "pwa-192x192.png",
    "revision": "cd96f612cc78399a481abcd9cffaa2a6"
  }, {
    "url": "logo-qubits-solar.png",
    "revision": "ac446b60e83d67933a58e44157b47c4d"
  }, {
    "url": "logo-qubits-consultancy.png",
    "revision": "70e7ea26c3517c52dc45d3cf08144f55"
  }, {
    "url": "index.html",
    "revision": "473f0fd7e13f786e1c44812b0790a3d9"
  }, {
    "url": "icon.svg",
    "revision": "2d80f9c19f2e2a833c030c20b4e8f3b7"
  }, {
    "url": "favicon.png",
    "revision": "1bdf785a7eab188e82858faae6c7fda9"
  }, {
    "url": "favicon.ico",
    "revision": "082220f7765a0ab1efb7f9dcd700cb84"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "748d533b916f1cf4ae01fedfcdaa6af8"
  }, {
    "url": "assets/index-DmRbKyXw.js",
    "revision": null
  }, {
    "url": "assets/index-CER6D59A.css",
    "revision": null
  }, {
    "url": "assets/aistudio/_9F00FF_9e509ae2.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "748d533b916f1cf4ae01fedfcdaa6af8"
  }, {
    "url": "favicon.ico",
    "revision": "082220f7765a0ab1efb7f9dcd700cb84"
  }, {
    "url": "icon.svg",
    "revision": "2d80f9c19f2e2a833c030c20b4e8f3b7"
  }, {
    "url": "manifest.json",
    "revision": "cfead76194064d6d141fc7ad3f89e984"
  }, {
    "url": "pwa-192x192.png",
    "revision": "cd96f612cc78399a481abcd9cffaa2a6"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e605c83263dc1b015c95446723a978d0"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "e605c83263dc1b015c95446723a978d0"
  }, {
    "url": "manifest.webmanifest",
    "revision": "d3fdb3334d14b38b0ecda7759975c722"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
